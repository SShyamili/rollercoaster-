# rollercoaster-
This code checks the eligibilty of a person for a rollercoaster ride.
